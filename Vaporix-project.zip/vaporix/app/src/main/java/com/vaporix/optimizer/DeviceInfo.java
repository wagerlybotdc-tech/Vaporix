package com.vaporix.optimizer;

import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Environment;
import android.os.StatFs;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.WindowManager;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.Locale;

/** Everything here is read-only and uses only what an ordinary app is allowed to see. */
final class DeviceInfo {
    private DeviceInfo() {}

    static String model() { return Build.MANUFACTURER + " " + Build.MODEL; }

    static String android() {
        return "Android " + Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ")";
    }

    static String securityPatch() {
        return Build.VERSION.SDK_INT >= 23 ? Build.VERSION.SECURITY_PATCH : "Unknown";
    }

    static String soc() {
        String hw = Build.HARDWARE;
        String cpu = readCpuInfoField("Hardware");
        String gpu = hw != null && hw.toLowerCase(Locale.US).contains("samsungexynos8890")
                ? "Mali-T880 MP12" : "Not exposed to apps";
        return (cpu != null ? cpu : hw) + "  |  GPU: " + gpu;
    }

    static int cores() { return Runtime.getRuntime().availableProcessors(); }

    static long[] ramMb(Context c) {
        ActivityManager am = (ActivityManager) c.getSystemService(Context.ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        am.getMemoryInfo(mi);
        return new long[]{mi.totalMem / 1048576L, mi.availMem / 1048576L};
    }

    static long[] storageGb10(Context c) {
        // Returns {total, free} in tenths of a GB to avoid float math.
        StatFs s = new StatFs(Environment.getDataDirectory().getPath());
        long total = s.getTotalBytes();
        long free = s.getAvailableBytes();
        return new long[]{total * 10 / 1073741824L, free * 10 / 1073741824L};
    }

    static String display(Context c) {
        WindowManager wm = (WindowManager) c.getSystemService(Context.WINDOW_SERVICE);
        Display d = wm.getDefaultDisplay();
        DisplayMetrics m = new DisplayMetrics();
        d.getRealMetrics(m);
        return m.widthPixels + "x" + m.heightPixels + " @ "
                + String.format(Locale.US, "%.0f", d.getRefreshRate()) + " Hz, " + m.densityDpi + " dpi";
    }

    /** {levelPct, tempTenthsC, voltageMv, health, plugged, status} or null. */
    static int[] battery(Context c) {
        Intent i = c.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (i == null) return null;
        int level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
        int scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
        return new int[]{
                scale > 0 ? level * 100 / scale : level,
                i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0),
                i.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0),
                i.getIntExtra(BatteryManager.EXTRA_HEALTH, 1),
                i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0),
                i.getIntExtra(BatteryManager.EXTRA_STATUS, 1)};
    }

    static String healthName(int h) {
        switch (h) {
            case BatteryManager.BATTERY_HEALTH_GOOD: return "Good";
            case BatteryManager.BATTERY_HEALTH_OVERHEAT: return "Overheating";
            case BatteryManager.BATTERY_HEALTH_DEAD: return "Dead";
            case BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE: return "Over voltage";
            case BatteryManager.BATTERY_HEALTH_COLD: return "Cold";
            default: return "Unknown";
        }
    }

    /** Current frequency of core 0 in MHz, or -1 when the kernel hides it from apps. */
    static int cpuMhz(int core) {
        String s = readFirstLine("/sys/devices/system/cpu/cpu" + core + "/cpufreq/scaling_cur_freq");
        try { return s == null ? -1 : Integer.parseInt(s.trim()) / 1000; }
        catch (NumberFormatException e) { return -1; }
    }

    /** Hottest readable thermal zone in tenths of a degree C, or Integer.MIN_VALUE. */
    static int thermalTenthsC() {
        int best = Integer.MIN_VALUE;
        File[] zones = new File("/sys/class/thermal").listFiles();
        if (zones == null) return best;
        for (File z : zones) {
            if (!z.getName().startsWith("thermal_zone")) continue;
            String s = readFirstLine(new File(z, "temp").getPath());
            if (s == null) continue;
            try {
                int v = Integer.parseInt(s.trim());
                if (v > 1000) v /= 100; // millidegrees -> tenths
                else if (v < 200) v *= 10; // whole degrees -> tenths
                if (v > best && v < 1500) best = v;
            } catch (NumberFormatException ignored) { }
        }
        return best;
    }

    static boolean looksRooted() {
        String[] paths = {"/system/bin/su", "/system/xbin/su", "/sbin/su", "/su/bin/su",
                "/system/app/Superuser.apk", "/data/adb/magisk"};
        for (String p : paths) if (new File(p).exists()) return true;
        return false;
    }

    static String bootloader() {
        String locked = sysProp("ro.boot.flash.locked");
        String vb = sysProp("ro.boot.verifiedbootstate");
        if ("0".equals(locked)) return "Unlocked";
        if ("1".equals(locked)) return "Locked";
        if (vb != null && !vb.isEmpty()) return "Verified boot: " + vb;
        return "Not detectable from an app";
    }

    static String sysProp(String key) {
        try {
            Class<?> sp = Class.forName("android.os.SystemProperties");
            return (String) sp.getMethod("get", String.class).invoke(null, key);
        } catch (Throwable t) {
            return null;
        }
    }

    private static String readCpuInfoField(String field) {
        try (BufferedReader r = new BufferedReader(new FileReader("/proc/cpuinfo"))) {
            String line;
            while ((line = r.readLine()) != null) {
                if (line.startsWith(field)) {
                    int i = line.indexOf(':');
                    if (i > 0) return line.substring(i + 1).trim();
                }
            }
        } catch (Exception ignored) { }
        return null;
    }

    private static String readFirstLine(String path) {
        try (BufferedReader r = new BufferedReader(new FileReader(path))) {
            return r.readLine();
        } catch (Exception e) {
            return null;
        }
    }
}

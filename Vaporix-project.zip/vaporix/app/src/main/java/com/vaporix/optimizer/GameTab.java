package com.vaporix.optimizer;

import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Locale;

final class GameTab {
    private GameTab() {}

    static View build(final Context c, final MainActivity host) {
        LinearLayout page = Ui.column(c);

        // ---- Gaming mode ----------------------------------------------------
        LinearLayout g = Ui.card(c);
        g.addView(Ui.title(c, "Gaming mode"));
        g.addView(Ui.body(c, "Keeps the Wi-Fi radio at full speed and the CPU awake for the stream, so GeForce NOW does not hiccup when Android tries to save power. It does not kill other apps. Turn it off when you finish; it also auto-stops after 4 hours."));
        final boolean on = GameService.running;
        g.addView(Ui.button(c, on ? "Turn gaming mode off" : "Turn gaming mode on", !on, new View.OnClickListener() {
            @Override public void onClick(View v) {
                Intent i = new Intent(c, GameService.class);
                if (on) {
                    i.setAction(GameService.ACTION_STOP);
                    c.startService(i);
                } else if (Build.VERSION.SDK_INT >= 26) {
                    c.startForegroundService(i);
                } else {
                    c.startService(i);
                }
                new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                    @Override public void run() { host.show(2); }
                }, 400);
            }
        }));
        page.addView(g);

        // ---- Network test -----------------------------------------------------
        final LinearLayout net = Ui.card(c);
        net.addView(Ui.title(c, "GeForce NOW network check"));
        String[] w = NetTest.wifi(c);
        net.addView(Ui.row(c, "Connection", w[0], Ui.TEXT));
        net.addView(Ui.row(c, "Band", w[1], w[1].startsWith("2.4") ? Ui.WARN : Ui.TEXT));
        net.addView(Ui.row(c, "Signal", w[2], Ui.TEXT));
        net.addView(Ui.row(c, "Link speed", w[3], Ui.TEXT));
        final LinearLayout out = Ui.column(c);
        net.addView(out);
        net.addView(Ui.button(c, "Run network test", true, new View.OnClickListener() {
            @Override public void onClick(final View btn) {
                btn.setEnabled(false);
                out.removeAllViews();
                out.addView(Ui.body(c, "Testing..."));
                new Thread(new Runnable() {
                    @Override public void run() {
                        final NetTest.Result r = NetTest.run("play.geforcenow.com", 443);
                        new Handler(Looper.getMainLooper()).post(new Runnable() {
                            @Override public void run() {
                                out.removeAllViews();
                                out.addView(Ui.row(c, "Result", r.verdict, r.verdictColor));
                                if (r.sent > r.lost) {
                                    out.addView(Ui.row(c, "Latency", String.format(Locale.US,
                                            "%.0f ms avg (%.0f-%.0f)", r.avg, r.min, r.max), Ui.TEXT));
                                    out.addView(Ui.row(c, "Jitter", String.format(Locale.US, "%.1f ms", r.jitter), Ui.TEXT));
                                }
                                out.addView(Ui.row(c, "Failed connections", r.lost + " of " + r.sent, Ui.TEXT));
                                btn.setEnabled(true);
                            }
                        });
                    }
                }).start();
            }
        }));
        net.addView(Ui.body(c, "\nThis measures connection time to the GeForce NOW service, a good stand-in for lag and stability. It is not a bandwidth test."));
        page.addView(net);

        // ---- Streaming advice --------------------------------------------------
        LinearLayout tips = Ui.card(c);
        tips.addView(Ui.title(c, "Best settings for Fortnite on GeForce NOW"));
        tips.addView(Ui.body(c,
                "- Use 5 GHz Wi-Fi and sit in the same room as the router.\n"
              + "- Stream at 720p / 60 FPS on this phone. Higher resolutions add decoding load without looking much better on a 5.1\" screen.\n"
              + "- Bitrate: 5 Mbps is a good step up from 2.4 Mbps if your test shows no packet loss; go back down if it stutters.\n"
              + "- Pause downloads and cloud backups on every device on your network.\n"
              + "- Keep the phone cool: remove the case, lower brightness, don't game while fast-charging.\n"
              + "- Turn off Battery Saver during play; it throttles the CPU and Wi-Fi."));
        tips.addView(Ui.button(c, "Open battery optimization settings", false, new View.OnClickListener() {
            @Override public void onClick(View v) {
                c.startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
            }
        }));
        page.addView(tips);
        return page;
    }
}

package com.vaporix.optimizer;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.provider.Settings;
import android.view.View;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

final class TweaksTab {
    private TweaksTab() {}

    static View build(final Context c, final MainActivity host) {
        final Tweaks tw = new Tweaks(c);
        LinearLayout page = Ui.column(c);

        // ---- Restore point status ----------------------------------------
        LinearLayout rp = Ui.card(c);
        rp.addView(Ui.title(c, "Restore point"));
        rp.addView(Ui.body(c, tw.hasRestorePoint()
                ? "Saved " + tw.restorePointTime() + ". Your original settings are stored and can be put back at any time."
                : "A restore point is created automatically the first time you apply a tweak, before anything changes."));
        if (tw.hasRestorePoint()) {
            rp.addView(Ui.button(c, "Restore original settings", false, new View.OnClickListener() {
                @Override public void onClick(View v) {
                    new AlertDialog.Builder(c)
                            .setTitle("Restore original settings?")
                            .setMessage("Every tweak you applied will be set back to exactly how it was before.")
                            .setNegativeButton("Cancel", null)
                            .setPositiveButton("Restore", new DialogInterface.OnClickListener() {
                                @Override public void onClick(DialogInterface d, int w) {
                                    int n = tw.restore();
                                    Toast.makeText(c, n + " settings restored", Toast.LENGTH_SHORT).show();
                                    host.show(1);
                                }
                            }).show();
                }
            }));
        }
        page.addView(rp);

        // ---- Permission cards -------------------------------------------
        if (!tw.canWriteSystem()) {
            LinearLayout p = Ui.card(c);
            p.addView(Ui.title(c, "Step 1: allow Vaporix to change settings"));
            p.addView(Ui.body(c, "Android asks you to approve this once. It only lets Vaporix change the display and sound settings listed below."));
            p.addView(Ui.button(c, "Open permission screen", true, new View.OnClickListener() {
                @Override public void onClick(View v) {
                    c.startActivity(new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS,
                            Uri.parse("package:" + c.getPackageName())));
                }
            }));
            page.addView(p);
        }
        if (!tw.canWriteSecure()) {
            LinearLayout p = Ui.card(c);
            p.addView(Ui.title(c, "Step 2 (optional): unlock animation tweaks"));
            p.addView(Ui.body(c, "The 3 animation tweaks are the biggest 'feels faster' change but Android only allows them after a one-time computer command. Open Tools > Setup guide for the exact steps. Everything else works without it."));
            page.addView(p);
        }

        // ---- Tweak list --------------------------------------------------
        page.addView(Ui.section(c, "Safe speed and heat tweaks"));
        final List<Tweaks.Tweak> all = Tweaks.all();
        final List<CheckBox> boxes = new ArrayList<>();
        for (Tweaks.Tweak t : all) {
            LinearLayout card = Ui.card(c);
            CheckBox cb = new CheckBox(c);
            boolean ok = tw.available(t);
            boolean on = tw.isApplied(t);
            cb.setText(t.title + (on ? "   (applied)" : ""));
            cb.setTextColor(ok ? Ui.TEXT : Ui.MUTED);
            cb.setTextSize(15);
            cb.setEnabled(ok && !on);
            cb.setChecked(ok && !on);
            boxes.add(cb);
            card.addView(cb);
            card.addView(Ui.body(c, t.why));
            card.addView(Ui.text(c, "Side effect: " + t.sideEffect, 12, Ui.WARN, false));
            if (!ok) card.addView(Ui.text(c, t.needsSecure
                    ? "Locked until the ADB step is done" : "Locked until Step 1 is done", 12, Ui.MUTED, false));
            page.addView(card);
        }

        page.addView(Ui.button(c, "Apply selected tweaks", true, new View.OnClickListener() {
            @Override public void onClick(View v) {
                List<Tweaks.Tweak> chosen = new ArrayList<>();
                for (int i = 0; i < all.size(); i++) {
                    if (boxes.get(i).isChecked() && boxes.get(i).isEnabled()) chosen.add(all.get(i));
                }
                if (chosen.isEmpty()) {
                    Toast.makeText(c, "Nothing to apply", Toast.LENGTH_SHORT).show();
                    return;
                }
                int n = tw.apply(chosen);
                Toast.makeText(c, n + " tweaks applied. Restore point saved.", Toast.LENGTH_LONG).show();
                host.show(1);
            }
        }));
        return page;
    }
}

package com.vaporix.optimizer;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

/** Tiny view factory so the whole UI stays code-only (no XML layouts, minimal RAM). */
final class Ui {
    static final int BG = Color.parseColor("#0B0F14");
    static final int CARD = Color.parseColor("#141A22");
    static final int CARD_HI = Color.parseColor("#1B2430");
    static final int ACCENT = Color.parseColor("#3DE0C5");
    static final int ACCENT2 = Color.parseColor("#7C8CFF");
    static final int TEXT = Color.parseColor("#E8EEF5");
    static final int MUTED = Color.parseColor("#8A97A6");
    static final int WARN = Color.parseColor("#FFB454");
    static final int BAD = Color.parseColor("#FF6B6B");

    private Ui() {}

    static int dp(Context c, int v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    static GradientDrawable round(int color, int radiusDp, Context c) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(c, radiusDp));
        return d;
    }

    static LinearLayout column(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    static LinearLayout card(Context c) {
        LinearLayout l = column(c);
        l.setBackground(round(CARD, 16, c));
        int p = dp(c, 16);
        l.setPadding(p, p, p, p);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = dp(c, 12);
        l.setLayoutParams(lp);
        return l;
    }

    static TextView text(Context c, String s, int sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        return t;
    }

    static TextView title(Context c, String s) {
        TextView t = text(c, s, 17, TEXT, true);
        t.setPadding(0, 0, 0, dp(c, 4));
        return t;
    }

    static TextView body(Context c, String s) {
        TextView t = text(c, s, 13, MUTED, false);
        t.setLineSpacing(dp(c, 2), 1f);
        return t;
    }

    static TextView section(Context c, String s) {
        TextView t = text(c, s.toUpperCase(), 11, ACCENT, true);
        t.setLetterSpacing(0.12f);
        t.setPadding(dp(c, 4), dp(c, 14), 0, dp(c, 8));
        return t;
    }

    static Button button(Context c, String label, boolean primary, View.OnClickListener l) {
        Button b = new Button(c);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(14);
        b.setTextColor(primary ? BG : TEXT);
        b.setBackground(round(primary ? ACCENT : CARD_HI, 12, c));
        b.setStateListAnimator(null);
        b.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(c, 46));
        lp.topMargin = dp(c, 10);
        b.setLayoutParams(lp);
        return b;
    }

    static LinearLayout row(Context c, String left, String right, int rightColor) {
        LinearLayout r = new LinearLayout(c);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(0, dp(c, 5), 0, dp(c, 5));
        TextView a = text(c, left, 13, MUTED, false);
        TextView b = text(c, right, 13, rightColor, true);
        b.setGravity(Gravity.END);
        r.addView(a, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        r.addView(b, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.4f));
        return r;
    }

    static ProgressBar bar(Context c, int percent, int color) {
        ProgressBar p = new ProgressBar(c, null, android.R.attr.progressBarStyleHorizontal);
        p.setMax(100);
        p.setProgress(Math.max(0, Math.min(100, percent)));
        p.setProgressTintList(android.content.res.ColorStateList.valueOf(color));
        p.setProgressBackgroundTintList(android.content.res.ColorStateList.valueOf(CARD_HI));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(c, 6));
        lp.topMargin = dp(c, 6);
        p.setLayoutParams(lp);
        return p;
    }

    /** Colour a 0-100 "how full" value: fine, getting high, critical. */
    static int levelColor(int pct) {
        return pct >= 90 ? BAD : pct >= 75 ? WARN : ACCENT;
    }
}

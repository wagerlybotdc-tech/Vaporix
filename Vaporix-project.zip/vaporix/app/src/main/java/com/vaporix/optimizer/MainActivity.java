package com.vaporix.optimizer;

import android.app.Activity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final String[] TABS = {"Home", "Tweaks", "Game", "Tools"};
    private FrameLayout content;
    private final TextView[] tabViews = new TextView[TABS.length];
    private int current = 0;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = Ui.column(this);
        root.setBackgroundColor(Ui.BG);

        LinearLayout header = Ui.column(this);
        header.setPadding(Ui.dp(this, 20), Ui.dp(this, 22), Ui.dp(this, 20), Ui.dp(this, 6));
        TextView name = Ui.text(this, "Vaporix", 26, Ui.TEXT, true);
        TextView tag = Ui.text(this, DeviceInfo.model() + "  -  " + DeviceInfo.android(), 12, Ui.MUTED, false);
        header.addView(name);
        header.addView(tag);
        root.addView(header);

        content = new FrameLayout(this);
        root.addView(content, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setBackgroundColor(Ui.CARD);
        for (int i = 0; i < TABS.length; i++) {
            final int idx = i;
            TextView t = Ui.text(this, TABS[i], 13, Ui.MUTED, true);
            t.setGravity(Gravity.CENTER);
            t.setPadding(0, Ui.dp(this, 14), 0, Ui.dp(this, 14));
            t.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { show(idx); }
            });
            tabViews[i] = t;
            nav.addView(t, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        }
        root.addView(nav);
        setContentView(root);
        show(0);
    }

    @Override
    protected void onResume() {
        super.onResume();
        show(current); // permissions may have changed while in Settings
    }

    void show(int idx) {
        current = idx;
        View page;
        switch (idx) {
            case 1: page = TweaksTab.build(this, this); break;
            case 2: page = GameTab.build(this, this); break;
            case 3: page = ToolsTab.build(this, this); break;
            default: page = HomeTab.build(this);
        }
        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        LinearLayout holder = Ui.column(this);
        int p = Ui.dp(this, 16);
        holder.setPadding(p, Ui.dp(this, 8), p, p);
        holder.addView(page);
        sv.addView(holder);
        content.removeAllViews();
        content.addView(sv);
        for (int i = 0; i < tabViews.length; i++) {
            tabViews[i].setTextColor(i == idx ? Ui.ACCENT : Ui.MUTED);
        }
    }
}

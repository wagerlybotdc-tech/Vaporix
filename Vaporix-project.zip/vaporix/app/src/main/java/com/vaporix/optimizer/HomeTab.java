package com.vaporix.optimizer;

import android.content.Context;
import android.content.Intent;
import android.provider.Settings;
import android.view.View;
import android.widget.LinearLayout;

import java.util.List;
import java.util.Locale;

final class HomeTab {
    private HomeTab() {}

    static View build(final Context c) {
        LinearLayout page = Ui.column(c);

        // ---- Live health -------------------------------------------------
        LinearLayout health = Ui.card(c);
        health.addView(Ui.title(c, "Phone health"));

        long[] ram = DeviceInfo.ramMb(c);
        int ramUsed = ram[0] == 0 ? 0 : (int) (100 - ram[1] * 100 / ram[0]);
        health.addView(Ui.row(c, "Memory", ram[1] + " MB free of " + ram[0] + " MB", Ui.levelColor(ramUsed)));
        health.addView(Ui.bar(c, ramUsed, Ui.levelColor(ramUsed)));

        long[] st = DeviceInfo.storageGb10(c);
        int stUsed = st[0] == 0 ? 0 : (int) (100 - st[1] * 100 / st[0]);
        health.addView(Ui.row(c, "Storage", fmt(st[1]) + " GB free of " + fmt(st[0]) + " GB", Ui.levelColor(stUsed)));
        health.addView(Ui.bar(c, stUsed, Ui.levelColor(stUsed)));

        int[] bat = DeviceInfo.battery(c);
        int tempC10 = 0;
        if (bat != null) {
            tempC10 = bat[1];
            health.addView(Ui.row(c, "Battery", bat[0] + "%  -  " + DeviceInfo.healthName(bat[3]), Ui.TEXT));
            health.addView(Ui.bar(c, bat[0], bat[0] < 20 ? Ui.WARN : Ui.ACCENT));
            int tc = tempC10 >= 450 ? Ui.BAD : tempC10 >= 400 ? Ui.WARN : Ui.ACCENT;
            health.addView(Ui.row(c, "Battery temperature",
                    String.format(Locale.US, "%.1f C", tempC10 / 10.0), tc));
        }
        int th = DeviceInfo.thermalTenthsC();
        health.addView(Ui.row(c, "Chip temperature",
                th == Integer.MIN_VALUE ? "Hidden by Android on this phone"
                        : String.format(Locale.US, "%.1f C", th / 10.0), Ui.TEXT));
        page.addView(health);

        // ---- Recommendations ----------------------------------------------
        LinearLayout rec = Ui.card(c);
        rec.addView(Ui.title(c, "Recommended for you"));
        int count = 0;
        if (ramUsed >= 80) { rec.addView(Ui.body(c, "- Memory is tight. Restart the phone and avoid opening many apps before gaming. Vaporix never force-closes apps, because Android just reopens them and it wastes battery.\n")); count++; }
        if (stUsed >= 85) { rec.addView(Ui.body(c, "- Storage is nearly full, which slows an older phone a lot. Open Tools > Storage and free some space (keep at least 15% free).\n")); count++; }
        if (tempC10 >= 400) { rec.addView(Ui.body(c, "- The phone is warm. Take off the case, lower brightness and pause charging while gaming.\n")); count++; }
        Tweaks tw = new Tweaks(c);
        int applied = 0, total = 0;
        for (Tweaks.Tweak t : Tweaks.all()) { total++; if (tw.isApplied(t)) applied++; }
        if (applied < total) { rec.addView(Ui.body(c, "- " + (total - applied) + " safe speed tweaks are not applied yet. Open the Tweaks tab.\n")); count++; }
        String[] wifi = NetTest.wifi(c);
        if (wifi[1].startsWith("2.4")) { rec.addView(Ui.body(c, "- You are on 2.4 GHz Wi-Fi. Switch to 5 GHz for much steadier GeForce NOW streaming.\n")); count++; }
        if (count == 0) rec.addView(Ui.body(c, "Everything looks good. Nothing needs attention right now."));
        page.addView(rec);

        // ---- Heaviest apps ---------------------------------------------------
        LinearLayout apps = Ui.card(c);
        apps.addView(Ui.title(c, "Most-used apps (last 24 h)"));
        if (Usage.hasAccess(c)) {
            List<String[]> top = Usage.top(c, 6);
            if (top.isEmpty()) apps.addView(Ui.body(c, "No usage recorded yet."));
            for (String[] r : top) apps.addView(Ui.row(c, r[0], r[1], Ui.TEXT));
        } else {
            apps.addView(Ui.body(c, "Android hides per-app usage unless you allow Usage Access. It stays on your phone."));
            apps.addView(Ui.button(c, "Allow usage access", false, new View.OnClickListener() {
                @Override public void onClick(View v) {
                    c.startActivity(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS));
                }
            }));
        }
        page.addView(apps);

        // ---- Device ------------------------------------------------------
        LinearLayout dev = Ui.card(c);
        dev.addView(Ui.title(c, "This phone"));
        dev.addView(Ui.row(c, "Model", DeviceInfo.model(), Ui.TEXT));
        dev.addView(Ui.row(c, "Chip", DeviceInfo.soc() + "  (" + DeviceInfo.cores() + " cores)", Ui.TEXT));
        dev.addView(Ui.row(c, "Display", DeviceInfo.display(c), Ui.TEXT));
        dev.addView(Ui.row(c, "Security patch", DeviceInfo.securityPatch(), Ui.TEXT));
        dev.addView(Ui.row(c, "Root", DeviceInfo.looksRooted() ? "Detected" : "Not rooted", Ui.TEXT));
        dev.addView(Ui.row(c, "Bootloader", DeviceInfo.bootloader(), Ui.TEXT));
        page.addView(dev);
        return page;
    }

    private static String fmt(long tenths) { return (tenths / 10) + "." + (tenths % 10); }
}

package com.vaporix.optimizer;

import android.content.ContentResolver;
import android.content.Context;
import android.content.SharedPreferences;
import android.provider.Settings;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Every tweak is a reversible Android setting. Before the first change, the original value
 * of each setting is saved as the "restore point"; Restore puts every value back exactly.
 */
final class Tweaks {
    static final String SYSTEM = "system";
    static final String GLOBAL = "global";

    static final class Tweak {
        final String id, title, why, sideEffect, scope, key, value;
        final boolean needsSecure; // true = needs WRITE_SECURE_SETTINGS (one-time ADB grant)

        Tweak(String id, String title, String why, String sideEffect,
              String scope, String key, String value, boolean needsSecure) {
            this.id = id; this.title = title; this.why = why; this.sideEffect = sideEffect;
            this.scope = scope; this.key = key; this.value = value; this.needsSecure = needsSecure;
        }
    }

    static List<Tweak> all() {
        List<Tweak> t = new ArrayList<>();
        t.add(new Tweak("anim_window", "Window animations 0.5x",
                "Menus and windows open in half the time, so the phone feels much snappier.",
                "Less eye candy. Set back to 1x any time with Restore.",
                GLOBAL, "window_animation_scale", "0.5", true));
        t.add(new Tweak("anim_transition", "Transition animations 0.5x",
                "App-to-app and screen transitions finish faster.",
                "Slightly more abrupt transitions.",
                GLOBAL, "transition_animation_scale", "0.5", true));
        t.add(new Tweak("anim_duration", "Animator duration 0.5x",
                "Scrolling effects and in-app animations run quicker, less GPU work.",
                "A few apps may look a bit rushed.",
                GLOBAL, "animator_duration_scale", "0.5", true));
        t.add(new Tweak("haptics", "Touch vibration off",
                "Stops the vibration motor firing on every tap; saves a little battery.",
                "No buzz when you tap keys.",
                SYSTEM, "haptic_feedback_enabled", "0", false));
        t.add(new Tweak("touch_sounds", "Touch sounds off",
                "Removes tap sound processing.", "Silent taps.",
                SYSTEM, "sound_effects_enabled", "0", false));
        t.add(new Tweak("lock_sounds", "Lock sounds off",
                "Removes screen lock/unlock sound.", "Silent lock/unlock.",
                SYSTEM, "lockscreen_sounds_enabled", "0", false));
        t.add(new Tweak("timeout", "Screen timeout 30 s",
                "The display is the biggest heat and battery cost; shorter timeout cuts both.",
                "Screen sleeps sooner when idle.",
                SYSTEM, "screen_off_timeout", "30000", false));
        t.add(new Tweak("brightness", "Manual brightness ~40%",
                "A bright display is the largest source of heat on this phone. Lower brightness runs cooler.",
                "Dimmer screen; auto-brightness is switched off.",
                SYSTEM, "screen_brightness", "100", false));
        return t;
    }

    private final Context ctx;
    private final SharedPreferences prefs;

    Tweaks(Context c) {
        ctx = c.getApplicationContext();
        prefs = ctx.getSharedPreferences("vaporix_restore", Context.MODE_PRIVATE);
    }

    boolean canWriteSystem() { return Settings.System.canWrite(ctx); }

    boolean canWriteSecure() {
        return ctx.checkSelfPermission("android.permission.WRITE_SECURE_SETTINGS")
                == android.content.pm.PackageManager.PERMISSION_GRANTED;
    }

    boolean available(Tweak t) { return t.needsSecure ? canWriteSecure() : canWriteSystem(); }

    boolean hasRestorePoint() { return prefs.contains("snapshot"); }

    String restorePointTime() {
        long ts = prefs.getLong("snapshot_time", 0);
        return ts == 0 ? "none" : DateFormat.getDateTimeInstance().format(new Date(ts));
    }

    String current(Tweak t) {
        ContentResolver r = ctx.getContentResolver();
        return t.scope.equals(GLOBAL) ? Settings.Global.getString(r, t.key)
                : Settings.System.getString(r, t.key);
    }

    boolean isApplied(Tweak t) {
        String c = current(t);
        if (c == null) return false;
        try { return Math.abs(Float.parseFloat(c) - Float.parseFloat(t.value)) < 0.01f; }
        catch (NumberFormatException e) { return c.equals(t.value); }
    }

    /** Saves the original value of every tweak, once, before anything is changed. */
    private void ensureRestorePoint() {
        if (hasRestorePoint()) return;
        JSONObject snap = new JSONObject();
        try {
            for (Tweak t : all()) snap.put(t.scope + ":" + t.key, current(t) == null ? JSONObject.NULL : current(t));
            snap.put("system:screen_brightness_mode", Settings.System.getString(
                    ctx.getContentResolver(), "screen_brightness_mode"));
        } catch (JSONException ignored) { }
        prefs.edit().putString("snapshot", snap.toString())
                .putLong("snapshot_time", System.currentTimeMillis()).apply();
    }

    /** Apply the given tweaks. Returns how many were changed. */
    int apply(List<Tweak> chosen) {
        ensureRestorePoint();
        int n = 0;
        for (Tweak t : chosen) {
            if (!available(t)) continue;
            if (put(t.scope, t.key, t.value)) {
                if (t.id.equals("brightness")) put(SYSTEM, "screen_brightness_mode", "0");
                n++;
            }
        }
        return n;
    }

    /** Puts every saved value back and clears the restore point. Returns count restored. */
    int restore() {
        String json = prefs.getString("snapshot", null);
        if (json == null) return 0;
        int n = 0;
        try {
            JSONObject snap = new JSONObject(json);
            java.util.Iterator<String> it = snap.keys();
            while (it.hasNext()) {
                String k = it.next();
                int i = k.indexOf(':');
                String scope = k.substring(0, i), key = k.substring(i + 1);
                boolean secure = scope.equals(GLOBAL);
                if (secure ? !canWriteSecure() : !canWriteSystem()) continue;
                String v = snap.isNull(k) ? null : snap.getString(k);
                if (v == null) v = defaultFor(key); // setting did not exist before: use stock value
                if (v != null && put(scope, key, v)) n++;
            }
        } catch (JSONException ignored) { }
        prefs.edit().remove("snapshot").remove("snapshot_time").apply();
        return n;
    }

    private static String defaultFor(String key) {
        if (key.endsWith("_scale")) return "1.0";
        return null;
    }

    private boolean put(String scope, String key, String value) {
        try {
            ContentResolver r = ctx.getContentResolver();
            return scope.equals(GLOBAL) ? Settings.Global.putString(r, key, value)
                    : Settings.System.putString(r, key, value);
        } catch (SecurityException e) {
            return false;
        }
    }
}

package com.vaporix.optimizer;

import android.app.AppOpsManager;
import android.app.usage.UsageStats;
import android.app.usage.UsageStatsManager;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Process;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/** Which apps were on screen the most in the last 24 h (needs the user to grant Usage Access). */
final class Usage {
    private Usage() {}

    static boolean hasAccess(Context c) {
        AppOpsManager ops = (AppOpsManager) c.getSystemService(Context.APP_OPS_SERVICE);
        int mode = ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS,
                Process.myUid(), c.getPackageName());
        return mode == AppOpsManager.MODE_ALLOWED;
    }

    /** Returns up to {@code max} rows of {appName, minutes}. */
    static List<String[]> top(Context c, int max) {
        List<String[]> out = new ArrayList<>();
        UsageStatsManager usm = (UsageStatsManager) c.getSystemService(Context.USAGE_STATS_SERVICE);
        long now = System.currentTimeMillis();
        List<UsageStats> stats = usm.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, now - 24L * 3600_000L, now);
        if (stats == null) return out;
        Collections.sort(stats, new Comparator<UsageStats>() {
            @Override public int compare(UsageStats a, UsageStats b) {
                return Long.compare(b.getTotalTimeInForeground(), a.getTotalTimeInForeground());
            }
        });
        PackageManager pm = c.getPackageManager();
        for (UsageStats s : stats) {
            long min = s.getTotalTimeInForeground() / 60000L;
            if (min < 1) break;
            if (s.getPackageName().equals(c.getPackageName())) continue;
            String name;
            try {
                name = pm.getApplicationLabel(pm.getApplicationInfo(s.getPackageName(), 0)).toString();
            } catch (PackageManager.NameNotFoundException e) {
                name = s.getPackageName();
            }
            out.add(new String[]{name, min + " min"});
            if (out.size() >= max) break;
        }
        return out;
    }
}

package com.vaporix.optimizer;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Honest before/after test: a fixed CPU + memory workload timed in milliseconds (lower is faster).
 * Run it before applying tweaks, then again after. Results move with heat and background load,
 * so Vaporix reports the raw numbers and does not claim a guaranteed speed-up.
 */
final class Bench {
    private Bench() {}

    /** Call from a background thread. Returns total ms for the workload. */
    static long run() {
        long t0 = System.nanoTime();
        // CPU: integer + floating-point work
        double acc = 0;
        long x = 88172645463325252L;
        for (int i = 0; i < 6_000_000; i++) {
            x ^= x << 13; x ^= x >>> 7; x ^= x << 17;
            acc += Math.sqrt((x & 0xFFFF) + 1);
        }
        // Memory: allocate, fill and sum a block repeatedly
        int[] buf = new int[1_000_000];
        long sum = 0;
        for (int r = 0; r < 12; r++) {
            for (int i = 0; i < buf.length; i++) buf[i] = i * r;
            for (int i = 0; i < buf.length; i++) sum += buf[i];
        }
        if (acc == -1 || sum == -1) System.out.print(""); // keep the JIT from deleting the work
        return (System.nanoTime() - t0) / 1_000_000L;
    }

    static void save(Context c, String slot, long ms) {
        c.getSharedPreferences("vaporix_bench", Context.MODE_PRIVATE).edit().putLong(slot, ms).apply();
    }

    static long load(Context c, String slot) {
        SharedPreferences p = c.getSharedPreferences("vaporix_bench", Context.MODE_PRIVATE);
        return p.getLong(slot, -1);
    }
}

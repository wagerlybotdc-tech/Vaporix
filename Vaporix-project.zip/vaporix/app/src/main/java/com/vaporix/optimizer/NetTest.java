package com.vaporix.optimizer;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;

import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

/** Streaming-quality check: TCP connect latency, jitter and failure rate, plus Wi-Fi details. */
final class NetTest {
    static final class Result {
        int sent, lost;
        double avg, min, max, jitter;
        String verdict;
        int verdictColor;
    }

    private NetTest() {}

    /** Runs ~20 quick TCP handshakes. Call from a background thread. */
    static Result run(String host, int port) {
        final int n = 20;
        List<Double> ms = new ArrayList<>();
        Result r = new Result();
        for (int i = 0; i < n; i++) {
            r.sent++;
            long t0 = System.nanoTime();
            try (Socket s = new Socket()) {
                s.connect(new InetSocketAddress(host, port), 1500);
                ms.add((System.nanoTime() - t0) / 1e6);
            } catch (Exception e) {
                r.lost++;
            }
            try { Thread.sleep(120); } catch (InterruptedException ignored) { }
        }
        if (ms.isEmpty()) {
            r.verdict = "No connection - check Wi-Fi";
            r.verdictColor = Ui.BAD;
            return r;
        }
        double sum = 0, mn = Double.MAX_VALUE, mx = 0;
        for (double d : ms) { sum += d; mn = Math.min(mn, d); mx = Math.max(mx, d); }
        r.avg = sum / ms.size(); r.min = mn; r.max = mx;
        double j = 0;
        for (int i = 1; i < ms.size(); i++) j += Math.abs(ms.get(i) - ms.get(i - 1));
        r.jitter = ms.size() > 1 ? j / (ms.size() - 1) : 0;

        double lossPct = r.lost * 100.0 / r.sent;
        if (lossPct > 5 || r.avg > 80 || r.jitter > 25) {
            r.verdict = "Poor for cloud gaming"; r.verdictColor = Ui.BAD;
        } else if (lossPct > 1 || r.avg > 40 || r.jitter > 12) {
            r.verdict = "Playable, may stutter"; r.verdictColor = Ui.WARN;
        } else {
            r.verdict = "Great for cloud gaming"; r.verdictColor = Ui.ACCENT;
        }
        return r;
    }

    static String[] wifi(Context c) {
        ConnectivityManager cm = (ConnectivityManager) c.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo ni = cm.getActiveNetworkInfo();
        if (ni == null || !ni.isConnected()) return new String[]{"Offline", "-", "-", "-"};
        if (ni.getType() != ConnectivityManager.TYPE_WIFI) return new String[]{ni.getTypeName(), "-", "-", "-"};
        WifiManager wm = (WifiManager) c.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        WifiInfo wi = wm.getConnectionInfo();
        int freq = wi.getFrequency(); // API 21+
        String band = freq > 4900 ? "5 GHz (best for streaming)" : freq > 0 ? "2.4 GHz (try 5 GHz)" : "Unknown";
        int rssi = wi.getRssi();
        String sig = rssi + " dBm (" + (rssi >= -55 ? "excellent" : rssi >= -67 ? "good"
                : rssi >= -75 ? "weak" : "very weak") + ")";
        return new String[]{"Wi-Fi", band, sig, wi.getLinkSpeed() + " Mbps link"};
    }
}

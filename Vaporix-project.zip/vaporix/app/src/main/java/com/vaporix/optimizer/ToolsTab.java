package com.vaporix.optimizer;

import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.Toast;

import java.io.File;

final class ToolsTab {
    private ToolsTab() {}

    static View build(final Context c, final MainActivity host) {
        LinearLayout page = Ui.column(c);

        // ---- Before / after test -------------------------------------------
        final LinearLayout bench = Ui.card(c);
        bench.addView(Ui.title(c, "Before and after test"));
        bench.addView(Ui.body(c, "Runs a fixed CPU and memory workload and reports how long it took (lower is faster). Run it before applying tweaks, then again after. Let the phone cool for a minute between runs for fair numbers."));
        long before = Bench.load(c, "before"), after = Bench.load(c, "after");
        bench.addView(Ui.row(c, "Before", before < 0 ? "not run" : before + " ms", Ui.TEXT));
        bench.addView(Ui.row(c, "After", after < 0 ? "not run" : after + " ms", Ui.TEXT));
        if (before > 0 && after > 0) {
            int pct = (int) Math.round((before - after) * 100.0 / before);
            bench.addView(Ui.row(c, "Difference", (pct >= 0 ? pct + "% faster" : (-pct) + "% slower")
                    + " (heat and background apps change this)", pct >= 0 ? Ui.ACCENT : Ui.WARN));
        }
        bench.addView(benchButton(c, host, "Run as BEFORE", "before", true));
        bench.addView(benchButton(c, host, "Run as AFTER", "after", false));
        page.addView(bench);

        // ---- Storage ---------------------------------------------------------
        LinearLayout st = Ui.card(c);
        st.addView(Ui.title(c, "Storage"));
        long[] s = DeviceInfo.storageGb10(c);
        st.addView(Ui.row(c, "Free space", (s[1] / 10) + "." + (s[1] % 10) + " GB of " + (s[0] / 10) + "." + (s[0] % 10) + " GB", Ui.TEXT));
        st.addView(Ui.body(c, "Android does not let apps delete other apps' caches, and Vaporix never deletes your files. The safe route is Android's own storage screen, where you review everything before anything is removed."));
        st.addView(Ui.button(c, "Open Android storage manager", true, new View.OnClickListener() {
            @Override public void onClick(View v) {
                c.startActivity(new Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS));
            }
        }));
        st.addView(Ui.button(c, "Clear Vaporix's own cache", false, new View.OnClickListener() {
            @Override public void onClick(View v) {
                long freed = wipe(c.getCacheDir());
                Toast.makeText(c, "Freed " + (freed / 1024) + " KB", Toast.LENGTH_SHORT).show();
            }
        }));
        page.addView(st);

        // ---- Setup guide ------------------------------------------------------
        LinearLayout g = Ui.card(c);
        g.addView(Ui.title(c, "Setup guide: unlock animation tweaks"));
        g.addView(Ui.body(c,
                "One-time, needs a computer (no root, nothing is modified permanently):\n\n"
              + "1. On the phone: Settings > About phone > Software information, tap Build number 7 times.\n"
              + "2. Settings > Developer options > turn on USB debugging.\n"
              + "3. Plug into the computer, install Android platform-tools, and run:\n\n"
              + "adb shell pm grant com.vaporix.optimizer android.permission.WRITE_SECURE_SETTINGS\n\n"
              + "4. Reopen Vaporix. The animation tweaks unlock. Restore sets them back to 1x."));
        page.addView(g);

        // ---- Honest limits ----------------------------------------------------
        LinearLayout h = Ui.card(c);
        h.addView(Ui.title(c, "What Vaporix will not do"));
        h.addView(Ui.body(c,
                "- No fake RAM boost: Android manages memory itself, and force-closing apps makes the phone slower and drains battery.\n"
              + "- No overclocking or guaranteed FPS: that needs root and custom kernels, which are risky and not included.\n"
              + "- No automatic deleting of your files, apps or system files.\n"
              + "- Chip temperature may be hidden by Android 8; battery temperature always works.\n"
              + "\nNeeds root or newer Android (not available here): CPU governor control, per-app RAM and CPU readouts, scheduled auto-cleaning."));
        page.addView(h);
        return page;
    }

    private static View benchButton(final Context c, final MainActivity host, String label,
                                    final String slot, boolean primary) {
        return Ui.button(c, label, primary, new View.OnClickListener() {
            @Override public void onClick(final View v) {
                v.setEnabled(false);
                Toast.makeText(c, "Running... about 2 seconds", Toast.LENGTH_SHORT).show();
                new Thread(new Runnable() {
                    @Override public void run() {
                        Bench.run(); // warm-up so the JIT is not part of the score
                        long best = Long.MAX_VALUE;
                        for (int i = 0; i < 3; i++) best = Math.min(best, Bench.run());
                        final long ms = best;
                        new Handler(Looper.getMainLooper()).post(new Runnable() {
                            @Override public void run() {
                                Bench.save(c, slot, ms);
                                host.show(3);
                            }
                        });
                    }
                }).start();
            }
        });
    }

    private static long wipe(File dir) {
        long n = 0;
        File[] files = dir == null ? null : dir.listFiles();
        if (files == null) return 0;
        for (File f : files) {
            if (f.isDirectory()) n += wipe(f);
            n += f.length();
            //noinspection ResultOfMethodCallIgnored
            f.delete();
        }
        return n;
    }
}

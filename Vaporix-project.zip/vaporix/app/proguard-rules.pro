# Vaporix is pure Java with no reflection; default shrinking rules are enough.

# Vaporix

A lightweight, honest optimizer for the Samsung Galaxy S7 (Android 8.0). Pure Java, no libraries,
no root. Tabs: Home (live health + recommendations), Tweaks (with restore point), Game
(gaming mode + GeForce NOW network check), Tools (before/after test, storage, setup guide).

## Get the APK (no Android Studio needed)

1. Create a free account at github.com and make a new repository (private is fine).
2. Upload everything in this folder to it, keeping the `.github` folder
   (on a computer: "Add file > Upload files", drag the whole unzipped folder in).
3. Open the repository's **Actions** tab, pick **Build Vaporix APK**, press **Run workflow**.
4. After about 3 minutes, open the finished run and download **Vaporix-APK** at the bottom.
   Unzip it to get `app-release.apk`.
5. Copy the APK to your phone and open it. Allow "Install unknown apps" for your file manager
   or browser when Android asks.

## Build it yourself instead

Open this folder in Android Studio (Koala or newer), then Build > Build APK(s). Or run
`gradle :app:assembleRelease` with JDK 17 and the Android SDK (platform 34) installed.
The release build is signed with the debug key so it installs directly.

## Restore point

The first time you apply a tweak, Vaporix saves the original value of every setting it can
change. Tweaks tab > "Restore original settings" puts them all back exactly.
